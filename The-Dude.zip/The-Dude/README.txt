# The-Dude
Images from the classic film "The Big Lebowski" for pwnagotchi's custom faces.
Some of these are a little grainy when viewed on the pawnagotchi, but I think they're a funny addition.
There are extra images in the directory, in case you want to swap out some of them.
I also included my photoshop document, in case you want to edit them further in Photoshop.

I use Jayofelony's image for my pwnagotchi:
https://github.com/jayofelony/pwnagotchi 

I used this video to help me get the images into the custom-faces directory, and to set up the config .toml file.
https://www.youtube.com/watch?v=X-5jN0WjurQ 

Along with these tutorials.
https://github.com/roodriiigooo/PWNAGOTCHI-CUSTOM-FACES-MOD 
https://pwnagotchi.org/customization/custom-faces-mod/index.html 

However, I did not need to edit the classes as instructed to do at the bottom of the page of the 2nd URL.
Everything worked just adding the files to a directory "custom-faces" in the root directory.
Then edit the config.toml file to use the images instead of the emojis.

Enjoy!